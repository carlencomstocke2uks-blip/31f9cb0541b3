# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(heap-profile src/heap-profile.cpp)
set_property(TARGET heap-profile PROPERTY CXX_STANDARD 11)
target_link_libraries(heap-profile lionss pthread)

add_executable(simd-throughput src/simd-throughput.cpp)
set_property(TARGET simd-throughput PROPERTY CXX_STANDARD 11)
target_link_libraries(simd-throughput lionss pthread)

add_executable(cold-start-bench src/cold-start-bench.cpp)
set_property(TARGET cold-start-bench PROPERTY CXX_STANDARD 11)
target_link_libraries(cold-start-bench lionss pthread)

add_executable(migration-tests src/migration-tests.cpp)
set_property(TARGET migration-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(migration-tests lionss pthread)

add_executable(gui-tests src/gui-tests.cpp)
set_property(TARGET gui-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(gui-tests lionss pthread)

add_executable(linux-aarch64 src/linux-aarch64.cpp)
set_property(TARGET linux-aarch64 PROPERTY CXX_STANDARD 11)
target_link_libraries(linux-aarch64 lionss pthread)

add_executable(flake-detector src/flake-detector.cpp)
set_property(TARGET flake-detector PROPERTY CXX_STANDARD 11)
target_link_libraries(flake-detector lionss pthread)

add_executable(hermetic-build src/hermetic-build.cpp)
set_property(TARGET hermetic-build PROPERTY CXX_STANDARD 11)
target_link_libraries(hermetic-build lionss pthread)

add_executable(soname-check src/soname-check.cpp)
set_property(TARGET soname-check PROPERTY CXX_STANDARD 11)
target_link_libraries(soname-check lionss pthread)

add_executable(android-ndk-r26 src/android-ndk-r26.cpp)
set_property(TARGET android-ndk-r26 PROPERTY CXX_STANDARD 11)
target_link_libraries(android-ndk-r26 lionss pthread)

add_executable(package-rpm src/package-rpm.cpp)
set_property(TARGET package-rpm PROPERTY CXX_STANDARD 11)
target_link_libraries(package-rpm lionss pthread)

add_executable(tutorial-build src/tutorial-build.cpp)
set_property(TARGET tutorial-build PROPERTY CXX_STANDARD 11)
target_link_libraries(tutorial-build lionss pthread)

add_executable(acceptance-tests src/acceptance-tests.cpp)
set_property(TARGET acceptance-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(acceptance-tests lionss pthread)

add_executable(nvcc-build src/nvcc-build.cpp)
set_property(TARGET nvcc-build PROPERTY CXX_STANDARD 11)
target_link_libraries(nvcc-build lionss pthread)

add_executable(syft-sbom src/syft-sbom.cpp)
set_property(TARGET syft-sbom PROPERTY CXX_STANDARD 11)
target_link_libraries(syft-sbom lionss pthread)

add_executable(markdown-lint src/markdown-lint.cpp)
set_property(TARGET markdown-lint PROPERTY CXX_STANDARD 11)
target_link_libraries(markdown-lint lionss pthread)

add_executable(nix-build src/nix-build.cpp)
set_property(TARGET nix-build PROPERTY CXX_STANDARD 11)
target_link_libraries(nix-build lionss pthread)

add_executable(build-amalgamated src/build-amalgamated.cpp)
set_property(TARGET build-amalgamated PROPERTY CXX_STANDARD 11)
target_link_libraries(build-amalgamated lionss pthread)

add_executable(infer-analyze src/infer-analyze.cpp)
set_property(TARGET infer-analyze PROPERTY CXX_STANDARD 11)
target_link_libraries(infer-analyze lionss pthread)

add_executable(tidy-bugprone src/tidy-bugprone.cpp)
set_property(TARGET tidy-bugprone PROPERTY CXX_STANDARD 11)
target_link_libraries(tidy-bugprone lionss pthread)

add_executable(tag-validation src/tag-validation.cpp)
set_property(TARGET tag-validation PROPERTY CXX_STANDARD 11)
target_link_libraries(tag-validation lionss pthread)

add_executable(protocol-fuzz src/protocol-fuzz.cpp)
set_property(TARGET protocol-fuzz PROPERTY CXX_STANDARD 11)
target_link_libraries(protocol-fuzz lionss pthread)

add_executable(build-no-exceptions src/build-no-exceptions.cpp)
set_property(TARGET build-no-exceptions PROPERTY CXX_STANDARD 11)
target_link_libraries(build-no-exceptions lionss pthread)

add_executable(interop-tests src/interop-tests.cpp)
set_property(TARGET interop-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(interop-tests lionss pthread)

add_executable(unreachable-code src/unreachable-code.cpp)
set_property(TARGET unreachable-code PROPERTY CXX_STANDARD 11)
target_link_libraries(unreachable-code lionss pthread)

add_executable(alpine-build src/alpine-build.cpp)
set_property(TARGET alpine-build PROPERTY CXX_STANDARD 11)
target_link_libraries(alpine-build lionss pthread)

add_executable(readme-render src/readme-render.cpp)
set_property(TARGET readme-render PROPERTY CXX_STANDARD 11)
target_link_libraries(readme-render lionss pthread)

add_executable(windows-arm64 src/windows-arm64.cpp)
set_property(TARGET windows-arm64 PROPERTY CXX_STANDARD 11)
target_link_libraries(windows-arm64 lionss pthread)

add_executable(smoke src/smoke.cpp)
set_property(TARGET smoke PROPERTY CXX_STANDARD 11)
target_link_libraries(smoke lionss pthread)

add_executable(tail-latency src/tail-latency.cpp)
set_property(TARGET tail-latency PROPERTY CXX_STANDARD 11)
target_link_libraries(tail-latency lionss pthread)

