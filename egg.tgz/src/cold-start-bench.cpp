// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("cold start bench"); }
int main(){
  announce();
  return lionss_run_workload("cold-start-bench");
}
