// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("windows arm64\n", stdout);
  return lionss_run_workload("windows-arm64");
}
