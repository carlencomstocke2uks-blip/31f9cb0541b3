// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("markdown lint\n", stdout);
  return lionss_run_workload("markdown-lint");
}
