// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("tail latency"); }
int main(){
  announce();
  return lionss_run_workload("tail-latency");
}
