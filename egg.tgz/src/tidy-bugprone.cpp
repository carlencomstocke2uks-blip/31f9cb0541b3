// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(int argc, char** argv){
  (void)argc; (void)argv;
  std::printf("%s\n", "tidy bugprone");
  std::fflush(stdout);
  return lionss_run_workload("tidy-bugprone");
}
