// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("flake detector\n", stdout);
  return lionss_run_workload("flake-detector");
}
