// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("unreachable code\n", stdout);
  return lionss_run_workload("unreachable-code");
}
